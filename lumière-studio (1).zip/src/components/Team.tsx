import { motion } from 'motion/react';
import { Camera, Compass, Award, Linkedin, Twitter } from 'lucide-react';
import { team } from '../data';

export default function Team() {
  return (
    <section id="team" className="py-24 sm:py-32 bg-white relative overflow-hidden">
      {/* Visual background details */}
      <div className="absolute left-12 bottom-12 w-[1px] h-48 bg-zinc-200 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 sm:px-10 relative z-10">
        
        {/* Section Heading */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-6">
          <div className="space-y-4">
            <span className="text-[10px] font-mono text-gold tracking-[0.3em] uppercase block">Design Guild</span>
            <h2 className="font-serif text-3xl sm:text-5xl font-light text-luxury-dark tracking-tight">
              Our Visionary <span className="italic font-normal text-gold">Aesthetes.</span>
            </h2>
            <p className="text-luxury-gray text-xs sm:text-sm font-light max-w-lg leading-relaxed">
              We are a collective of classicists, modernists, and master artisans who believe in the deep physical integrity of the built environment.
            </p>
          </div>
          <div className="text-[11px] font-mono text-gold uppercase tracking-widest border border-gold/30 px-5 py-2.5 rounded-full">
            4 Principal Leads · 24 Artisans
          </div>
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {team.map((member, index) => (
            <motion.div
              key={member.id}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.8, delay: index * 0.1, ease: [0.16, 1, 0.3, 1] }}
              className="group relative flex flex-col justify-between h-[450px] overflow-hidden rounded-3xl bg-[#FAFAFA] border border-zinc-200/50 hover:shadow-2xl hover:shadow-zinc-300/40 transition-all duration-500"
            >
              {/* Photo wrapping with hover scaling */}
              <div className="relative w-full h-[320px] overflow-hidden bg-zinc-100">
                <img
                  src={member.image}
                  alt={member.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover scale-100 group-hover:scale-105 transition-transform duration-700 ease-[0.16,1,0.3,1]"
                />

                {/* ShShroud Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-400 flex items-end justify-center pb-6" />

                {/* Social icons on photo hover */}
                <div className="absolute bottom-6 left-0 right-0 flex justify-center gap-4 opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all duration-400 z-10">
                  <a href="#linkedin" className="w-8 h-8 rounded-full bg-white/10 hover:bg-gold backdrop-blur-md text-white flex items-center justify-center transition-all">
                    <Linkedin className="w-3.5 h-3.5" />
                  </a>
                  <a href="#twitter" className="w-8 h-8 rounded-full bg-white/10 hover:bg-gold backdrop-blur-md text-white flex items-center justify-center transition-all">
                    <Twitter className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* Info Container */}
              <div className="p-5 flex-grow flex flex-col justify-between bg-white border-t border-zinc-100">
                <div>
                  <h3 className="font-serif text-lg font-medium text-luxury-dark tracking-wide leading-none group-hover:text-gold transition-colors duration-300">
                    {member.name}
                  </h3>
                  <span className="text-[10px] font-mono text-luxury-gray uppercase tracking-wider block mt-1.5">
                    {member.role}
                  </span>
                </div>

                {/* Specialty tag */}
                <div className="mt-2 pt-2.5 border-t border-zinc-100 flex items-center gap-1.5">
                  <span className="text-[9px] font-mono text-gold uppercase tracking-widest block leading-none">
                    SPECIALTY:
                  </span>
                  <span className="text-[10px] text-luxury-dark font-sans font-light leading-none truncate block max-w-[150px]">
                    {member.specialty}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  );
}
