import { motion } from 'motion/react';
import { ArrowRight, Sparkles, Compass } from 'lucide-react';

interface CTAProps {
  onOpenConsultation: () => void;
}

export default function CTA({ onOpenConsultation }: CTAProps) {
  return (
    <section id="contact" className="relative py-28 sm:py-36 bg-luxury-dark text-white overflow-hidden">
      
      {/* Immersive high-end background image */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-fixed opacity-40 scale-102"
        style={{ 
          backgroundImage: `linear-gradient(to bottom, rgba(31, 41, 55, 0.8), rgba(17, 17, 17, 0.9)), url('https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=2000&q=80')` 
        }}
      />

      {/* Decorative vector lines */}
      <div className="absolute top-0 left-24 bottom-0 w-[1px] bg-white/5 pointer-events-none" />
      <div className="absolute top-0 right-24 bottom-0 w-[1px] bg-white/5 pointer-events-none" />

      <div className="relative z-10 max-w-4xl mx-auto px-6 sm:px-10 text-center space-y-8">
        
        {/* Spark tag */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="inline-flex items-center gap-2 bg-white/5 border border-white/10 px-4 py-1.5 rounded-full"
        >
          <Compass className="w-3.5 h-3.5 text-gold animate-spin-slow" />
          <span className="text-[10px] font-mono text-gold uppercase tracking-[0.2em] font-semibold">
            Bespoke Commissions Open
          </span>
        </motion.div>

        {/* Master Heading */}
        <motion.h2
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="font-serif text-4xl sm:text-6xl font-light tracking-tight text-white leading-tight"
        >
          Let’s Create Your <br />
          <span className="italic font-normal text-gold">Dream Space.</span>
        </motion.h2>

        {/* Support block */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
          className="text-white/70 font-sans text-sm sm:text-base font-light max-w-xl mx-auto leading-relaxed"
        >
          We are currently selecting private commissions and architectural developments for the upcoming season. Let us schedule an initial discovery call at our atelier or your residence.
        </motion.p>

        {/* Epic Booking CTA */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="pt-4 flex justify-center"
        >
          <button
            id="cta-large-book-btn"
            onClick={onOpenConsultation}
            className="group bg-gold hover:bg-gold-hover text-white font-sans text-xs sm:text-sm uppercase tracking-[0.25em] font-medium py-4 px-10 rounded-full transition-all duration-300 flex items-center justify-center gap-3.5 shadow-xl shadow-gold/20 cursor-pointer hover:shadow-gold/30 hover:scale-103"
          >
            <span>Initiate Spatial Inquiry</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1.5 transition-transform" />
          </button>
        </motion.div>

        {/* Studio coordinates */}
        <div className="pt-10 flex flex-wrap justify-center gap-x-8 gap-y-4 text-[10px] font-mono text-white/40 uppercase tracking-widest">
          <span>LONDON ATELIER: +44 20 7946 0192</span>
          <span>·</span>
          <span>ZURICH ATELIER: +41 44 250 8290</span>
          <span>·</span>
          <span>NEW YORK OFFICE: +1 212 555 0190</span>
        </div>

      </div>
    </section>
  );
}
