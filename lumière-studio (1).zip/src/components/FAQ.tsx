import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus, HelpCircle } from 'lucide-react';
import { faqs } from '../data';

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleFaq = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-24 sm:py-32 bg-[#FAFAFA] relative overflow-hidden">
      {/* Decorative vertical lines */}
      <div className="absolute left-24 inset-y-0 w-[1px] bg-zinc-200/50 pointer-events-none" />

      <div className="max-w-4xl mx-auto px-6 sm:px-10 relative z-10">
        
        {/* Section Heading */}
        <div className="text-center max-w-xl mx-auto mb-20 space-y-4">
          <span className="text-[10px] font-mono text-gold tracking-[0.3em] uppercase block">Aesthetic Clarity</span>
          <h2 className="font-serif text-3xl sm:text-5xl font-light text-luxury-dark tracking-tight">
            Curious <span className="italic font-normal text-gold">Inquiries.</span>
          </h2>
          <div className="w-12 h-[1px] bg-gold/50 mx-auto my-4" />
          <p className="text-luxury-gray text-xs sm:text-sm font-light">
            We operate with absolute transparency. Here are responses to the questions most frequently posed by our distinguished partners.
          </p>
        </div>

        {/* FAQ Accordion List */}
        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index;
            return (
              <div
                key={index}
                className={`border rounded-2xl transition-all duration-500 overflow-hidden ${
                  isOpen 
                    ? 'bg-white border-gold shadow-md' 
                    : 'bg-white/60 border-zinc-200/50 hover:bg-white hover:border-zinc-300'
                }`}
              >
                {/* Trigger */}
                <button
                  id={`faq-trigger-${index}`}
                  onClick={() => toggleFaq(index)}
                  className="w-full text-left px-6 py-5 sm:py-6 flex items-start justify-between gap-4 cursor-pointer"
                  aria-expanded={isOpen}
                >
                  <div className="flex gap-4">
                    <span className="font-serif text-gold text-sm sm:text-base font-semibold mt-0.5">
                      {index + 1 < 10 ? `0${index + 1}` : index + 1}
                    </span>
                    <span className="font-serif text-base sm:text-lg font-medium text-luxury-dark tracking-wide">
                      {faq.question}
                    </span>
                  </div>

                  <div className={`p-1.5 rounded-full bg-[#F4F1EB] text-gold transition-transform duration-500 shrink-0 ${
                    isOpen ? 'rotate-180 bg-gold text-white' : ''
                  }`}>
                    {isOpen ? <Minus className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  </div>
                </button>

                {/* Dropdown Container */}
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.35, ease: 'easeInOut' }}
                    >
                      <div className="px-6 pb-6 pt-1 sm:px-14 border-t border-zinc-100">
                        <p className="text-luxury-gray text-xs sm:text-sm font-light leading-relaxed">
                          {faq.answer}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
