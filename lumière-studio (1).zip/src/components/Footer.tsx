import React, { useState } from 'react';
import { Mail, Phone, MapPin, Instagram, Facebook, Linkedin, ArrowRight, CheckCircle } from 'lucide-react';

export default function Footer() {
  const [subscribed, setSubscribed] = useState(false);
  const [email, setEmail] = useState('');

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setEmail('');
    }
  };

  const handleLinkClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const targetElement = document.querySelector(href);
    if (targetElement) {
      const offset = 80;
      const elementPosition = targetElement.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.scrollY - offset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-luxury-dark text-white pt-20 pb-10 border-t border-white/5 relative overflow-hidden">
      
      {/* Footer Grid */}
      <div className="max-w-7xl mx-auto px-6 sm:px-10 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 lg:gap-8 pb-16 border-b border-white/10 relative z-10">
        
        {/* Col 1: Brand Pitch (4 cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="flex flex-col">
            <span className="font-serif text-2xl font-light tracking-[0.25em] text-white">LUMIÈRE</span>
            <span className="text-[8px] font-mono uppercase tracking-[0.4em] text-gold -mt-1">STUDIO</span>
          </div>
          <p className="text-white/60 text-xs sm:text-sm font-light leading-relaxed max-w-sm">
            Orchestrating high-end residential and commercial architecture to construct timeless silence and emotional resonance since 2011.
          </p>
          {/* Social Cluster */}
          <div className="flex gap-4 pt-2">
            <a href="#instagram" className="w-8 h-8 rounded-full border border-white/15 hover:border-gold hover:text-gold flex items-center justify-center transition-colors">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="#facebook" className="w-8 h-8 rounded-full border border-white/15 hover:border-gold hover:text-gold flex items-center justify-center transition-colors">
              <Facebook className="w-4 h-4" />
            </a>
            <a href="#linkedin" className="w-8 h-8 rounded-full border border-white/15 hover:border-gold hover:text-gold flex items-center justify-center transition-colors">
              <Linkedin className="w-4 h-4" />
            </a>
          </div>
        </div>

        {/* Col 2: Directory Links (2 cols) */}
        <div className="lg:col-span-2 space-y-4">
          <h4 className="text-[10px] font-mono text-gold uppercase tracking-[0.25em] font-medium">Directory</h4>
          <ul className="space-y-2.5">
            {['About', 'Services', 'Projects', 'Testimonials', 'FAQ', 'Contact'].map((item) => (
              <li key={item}>
                <a
                  href={`#${item.toLowerCase()}`}
                  onClick={(e) => handleLinkClick(e, `#${item.toLowerCase()}`)}
                  className="text-xs text-white/60 hover:text-white font-sans font-light transition-colors"
                >
                  {item}
                </a>
              </li>
            ))}
          </ul>
        </div>

        {/* Col 3: Ateliers & Contact (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          <h4 className="text-[10px] font-mono text-gold uppercase tracking-[0.25em] font-medium">Our Ateliers</h4>
          <ul className="space-y-3 text-xs text-white/60 font-sans font-light">
            <li className="flex gap-2">
              <MapPin className="w-4 h-4 text-gold shrink-0" />
              <span>Avenue Montaigne 18, Paris</span>
            </li>
            <li className="flex gap-2">
              <MapPin className="w-4 h-4 text-gold shrink-0" />
              <span>Dufourstrasse 44, Zurich</span>
            </li>
            <li className="flex gap-2">
              <Phone className="w-4 h-4 text-gold shrink-0" />
              <a href="tel:+442079460192" className="hover:text-white transition-colors">
                +44 (0) 20 7946 0192
              </a>
            </li>
            <li className="flex gap-2">
              <Mail className="w-4 h-4 text-gold shrink-0" />
              <a href="mailto:atelier@lumiere-design.com" className="hover:text-white transition-colors">
                atelier@lumiere-design.com
              </a>
            </li>
          </ul>
        </div>

        {/* Col 4: Newsletter Subscription (3 cols) */}
        <div className="lg:col-span-3 space-y-4">
          <h4 className="text-[10px] font-mono text-gold uppercase tracking-[0.25em] font-medium">The Dispatch</h4>
          <p className="text-white/60 text-xs font-light leading-relaxed">
            Subscribe to receive private view invitations, architectural reports, and custom curation studies.
          </p>

          {!subscribed ? (
            <form onSubmit={handleSubscribe} className="space-y-2">
              <div className="relative">
                <input
                  type="email"
                  required
                  placeholder="Inquire email..."
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl py-2 px-4 text-xs focus:outline-none focus:border-gold focus:ring-1 focus:ring-gold text-white"
                />
                <button
                  id="newsletter-subscribe-btn"
                  type="submit"
                  className="absolute right-2 top-1.5 p-1 rounded-lg text-gold hover:text-white transition-colors cursor-pointer"
                  aria-label="Submit newsletter subscription"
                >
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>
          ) : (
            <div className="flex items-center gap-2.5 bg-gold/10 border border-gold/20 p-3 rounded-xl">
              <CheckCircle className="w-4 h-4 text-gold shrink-0" />
              <span className="text-[11px] text-gold font-sans">Subscription authenticated</span>
            </div>
          )}
        </div>

      </div>

      {/* Sub-Footer */}
      <div className="max-w-7xl mx-auto px-6 sm:px-10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-[10px] font-mono text-white/40 uppercase tracking-widest relative z-10">
        <div>
          © {currentYear} Lumière Studio. All spatial rights reserved.
        </div>
        <div className="flex gap-6">
          <a href="#privacy" className="hover:text-gold transition-colors">Privacy Policy</a>
          <a href="#terms" className="hover:text-gold transition-colors">Terms of Atelier</a>
        </div>
      </div>
    </footer>
  );
}
